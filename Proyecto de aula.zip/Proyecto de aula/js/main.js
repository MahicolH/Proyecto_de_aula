// js/main.js
document.addEventListener("DOMContentLoaded", () => {
    console.log("Frontend cargado correctamente.");
    // Aquí se pueden añadir validaciones de formularios, etc.
});

document.querySelectorAll('.btn-delete')?.forEach(btn => {
    btn.addEventListener('click', (e) => {
        e.preventDefault();
        if (confirm("¿Seguro que deseas eliminar esta tarea?")) {
            alert("Tarea eliminada (simulación)");
        }
    });
});
